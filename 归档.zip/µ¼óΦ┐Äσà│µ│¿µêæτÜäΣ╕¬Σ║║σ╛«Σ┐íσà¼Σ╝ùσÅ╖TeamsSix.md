---
title: 欢迎关注我的个人微信公众号：TeamsSix
date: 2017-12-19 07:07:07
id: 171219-070707
img: https://teamssix.oss-cn-hangzhou.aliyuncs.com/TEAMSSIX_long6.png
top: true
summary: 给大佬递茶，求关注 ~
---

![](https://teamssix.oss-cn-hangzhou.aliyuncs.com/TeamsSix_Subscription_Logo2.png)