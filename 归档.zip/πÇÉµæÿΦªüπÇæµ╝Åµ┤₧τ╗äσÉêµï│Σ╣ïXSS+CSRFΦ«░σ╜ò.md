---
title: 【摘要】漏洞组合拳之XSS+CSRF记录
date: 2020-02-06 20:29:59
id: 200206-202959
tags:
- XSS
- CSRF
- 组合拳
categories:
- 摘要
---

前几天，我在FreeBuf发布了一篇文章《漏洞组合拳之XSS+CSRF记录》，因为版权原因，无法在​这里发布。

文章里介绍了两种常见的组合拳方法，感兴趣的可以点击下方链接进行查看。

文章链接：[https://www.freebuf.com/vuls/225096.html](https://www.freebuf.com/vuls/225096.html)

<!--more-->

>更多信息欢迎关注我的个人微信公众号：TeamsSix
>本文原文地址：[https://www.teamssix.com/year/200206-202959.html](https://www.teamssix.com/year/200206-202959.html)

![](https://teamssix.oss-cn-hangzhou.aliyuncs.com/TeamsSix_Subscription_Logo2.png)